function d3_number(x) {
  return x != null && !isNaN(x);
}
